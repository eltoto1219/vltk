# vltk
to install (add editable for personal custimization)
```
git clone https://github.com/eltoto1219/vltk.git && cd vltk && pip install -e .
```
once data ready, all one needs to do is provide experiment, and dataset names, ie.
```
run exp lxmert gqa --yaml=libdata/eval_test.yaml --save_on_crash=true --email=your@email.com
```


