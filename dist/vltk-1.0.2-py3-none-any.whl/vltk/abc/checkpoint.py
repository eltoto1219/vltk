load_check_point()
