from vltk import adapters


class VisualGenome(adapters.VisnDataset):
    def schema():
        return {}

    def forward(json_files, splits):
        return {}
